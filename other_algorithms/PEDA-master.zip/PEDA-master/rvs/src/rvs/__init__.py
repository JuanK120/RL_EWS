"""rvs: Reinforcement Learning via Supervised Learning."""

__version__ = "0.1.0"
