#naive for paper ft6
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s0_r0
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s0_r0
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s0_r1
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s0_r1
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s0_r2
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s0_r2
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s0_r3
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s0_r3
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s0_r4
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s0_r4

python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s0.5_r0
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s0.5_r0
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s0.5_r1
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s0.5_r1
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s0.5_r2
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s0.5_r2
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s0.5_r3
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s0.5_r3
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s0.5_r4
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s0.5_r4

python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s1_r0
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s1_r0
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s1_r1
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s1_r1
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s1_r2
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s1_r2
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s1_r3
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s1_r3
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s1_r4
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s1_r4
#
#

python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s2_r0
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s2_r0
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s2_r1
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s2_r1
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s2_r2
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s2_r2
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s2_r3
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s2_r3
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s2_r4
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s2_r4


python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s3_r0
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s3_r0
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s3_r1
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s3_r1
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s3_r2
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s3_r2
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s3_r3
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s3_r3
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s3_r4
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s3_r4


python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s4_r0
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s4_r0
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s4_r1
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s4_r1
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s4_r2
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s4_r2
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s4_r3
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s4_r3
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s4_r4
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s4_r4



python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s5_r0
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s5_r0
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s5_r1
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s5_r1
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s5_r2
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s5_r2
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s5_r3
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s5_r3
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s5_r4
python test/eval_for_paper.py --env-name ft --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s5_r4


#
#naive for paper ft5
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s0_r0
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s0_r0
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s0_r1
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s0_r1
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s0_r2
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s0_r2
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s0_r3
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s0_r3
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s0_r4
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s0_r4

python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s0.5_r0
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s0.5_r0
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s0.5_r1
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s0.5_r1
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s0.5_r2
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s0.5_r2
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s0.5_r3
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s0.5_r3
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s0.5_r4
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s0.5_r4

python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s1_r0
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s1_r0
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s1_r1
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s1_r1
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s1_r2
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s1_r2
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s1_r3
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s1_r3
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s1_r4
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s1_r4
#
#

python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s2_r0
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s2_r0
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s2_r1
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s2_r1
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s2_r2
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s2_r2
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s2_r3
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s2_r3
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s2_r4
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s2_r4


python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s3_r0
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s3_r0
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s3_r1
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s3_r1
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s3_r2
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s3_r2
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s3_r3
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s3_r3
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s3_r4
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s3_r4


python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s4_r0
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s4_r0
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s4_r1
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s4_r1
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s4_r2
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s4_r2
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s4_r3
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s4_r3
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s4_r4
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s4_r4



python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s5_r0
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s5_r0
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s5_r1
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s5_r1
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s5_r2
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s5_r2
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s5_r3
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s5_r3
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s5_r4
python test/eval_for_paper.py --env-name ft5 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s5_r4

#naive for paper ft7
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s0_r0
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s0_r0
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s0_r1
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s0_r1
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s0_r2
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s0_r2
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s0_r3
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s0_r3
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s0_r4
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s0_r4

python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s0.5_r0
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s0.5_r0
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s0.5_r1
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s0.5_r1
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s0.5_r2
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s0.5_r2
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s0.5_r3
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s0.5_r3
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s0.5_r4
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s0.5_r4

python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s1_r0
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s1_r0
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s1_r1
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s1_r1
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s1_r2
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s1_r2
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s1_r3
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s1_r3
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s1_r4
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s1_r4
#
#

python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s2_r0
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s2_r0
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s2_r1
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s2_r1
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s2_r2
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s2_r2
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s2_r3
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s2_r3
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s2_r4
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s2_r4


python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s3_r0
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s3_r0
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s3_r1
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s3_r1
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s3_r2
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s3_r2
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s3_r3
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s3_r3
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s3_r4
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s3_r4


python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s4_r0
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s4_r0
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s4_r1
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s4_r1
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s4_r2
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s4_r2
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s4_r3
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s4_r3
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s4_r4
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s4_r4



python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s5_r0
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s5_r0
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s5_r1
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s5_r1
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s5_r2
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s5_r2
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s5_r3
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s5_r3
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltpareto  --name s5_r4
python test/eval_for_paper.py --env-name ft7 --method crl-naive --model  linear --gamma  0.99 --save crl/naive/saved/ --pltcontrol --name s5_r4



# #envelope ft6


# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0_r0
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0_r0
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0_r1
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0_r1
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0_r2
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0_r2
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0_r3
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0_r3
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0_r4
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0_r4
#
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0.5_r0
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0.5_r0
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0.5_r1
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0.5_r1
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0.5_r2
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0.5_r2
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0.5_r3
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0.5_r3
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0.5_r4
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0.5_r4
#
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s1_r0
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s1_r0
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s1_r1
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s1_r1
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s1_r2
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s1_r2
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s1_r3
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s1_r3
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s1_r4
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s1_r4
#
#
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s2_r0
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s2_r0
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s2_r1
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s2_r1
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s2_r2
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s2_r2
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s2_r3
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s2_r3
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s2_r4
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s2_r4
#
#
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s3_r0
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s3_r0
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s3_r1
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s3_r1
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s3_r2
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s3_r2
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s3_r3
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s3_r3
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s3_r4
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s3_r4
#
#
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s4_r0
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s4_r0
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s4_r1
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s4_r1
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s4_r2
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s4_r2
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s4_r3
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s4_r3
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s4_r4
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s4_r4
#
#
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s5_r0
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s5_r0
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s5_r1
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s5_r1
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s5_r2
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s5_r2
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s5_r3
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s5_r3
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s5_r4
# python test/eval_ft.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s5_r4
#

#envelope ft5 for paper
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0_r0
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0_r0
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0_r1
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0_r1
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0_r2
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0_r2
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0_r3
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0_r3
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0_r4
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0_r4

python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0.5_r0
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0.5_r0
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0.5_r1
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0.5_r1
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0.5_r2
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0.5_r2
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0.5_r3
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0.5_r3
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0.5_r4
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0.5_r4

python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s1_r0
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s1_r0
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s1_r1
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s1_r1
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s1_r2
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s1_r2
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s1_r3
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s1_r3
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s1_r4
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s1_r4


python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s2_r0
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s2_r0
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s2_r1
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s2_r1
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s2_r2
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s2_r2
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s2_r3
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s2_r3
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s2_r4
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s2_r4


python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s3_r0
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s3_r0
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s3_r1
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s3_r1
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s3_r2
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s3_r2
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s3_r3
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s3_r3
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s3_r4
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s3_r4


python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s4_r0
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s4_r0
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s4_r1
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s4_r1
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s4_r2
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s4_r2
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s4_r3
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s4_r3
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s4_r4
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s4_r4


python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s5_r0
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s5_r0
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s5_r1
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s5_r1
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s5_r2
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s5_r2
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s5_r3
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s5_r3
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s5_r4
python test/eval_for_paper.py --env-name ft5 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s5_r4

# #envelope ft6 for paper
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0_r0
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0_r0
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0_r1
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0_r1
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0_r2
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0_r2
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0_r3
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0_r3
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0_r4
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0_r4
#
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0.5_r0
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0.5_r0
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0.5_r1
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0.5_r1
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0.5_r2
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0.5_r2
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0.5_r3
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0.5_r3
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0.5_r4
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0.5_r4
#
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s1_r0
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s1_r0
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s1_r1
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s1_r1
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s1_r2
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s1_r2
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s1_r3
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s1_r3
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s1_r4
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s1_r4
#
#
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s2_r0
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s2_r0
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s2_r1
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s2_r1
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s2_r2
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s2_r2
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s2_r3
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s2_r3
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s2_r4
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s2_r4
#
#
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s3_r0
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s3_r0
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s3_r1
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s3_r1
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s3_r2
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s3_r2
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s3_r3
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s3_r3
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s3_r4
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s3_r4
#
#
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s4_r0
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s4_r0
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s4_r1
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s4_r1
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s4_r2
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s4_r2
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s4_r3
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s4_r3
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s4_r4
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s4_r4
#
#
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s5_r0
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s5_r0
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s5_r1
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s5_r1
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s5_r2
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s5_r2
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s5_r3
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s5_r3
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s5_r4
# python test/eval_for_paper.py --env-name ft --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s5_r4


#envelope ft5 for paper
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0_r0
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0_r0
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0_r1
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0_r1
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0_r2
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0_r2
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0_r3
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0_r3
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0_r4
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0_r4

python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0.5_r0
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0.5_r0
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0.5_r1
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0.5_r1
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0.5_r2
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0.5_r2
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0.5_r3
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0.5_r3
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s0.5_r4
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s0.5_r4

python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s1_r0
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s1_r0
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s1_r1
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s1_r1
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s1_r2
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s1_r2
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s1_r3
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s1_r3
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s1_r4
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s1_r4


python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s2_r0
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s2_r0
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s2_r1
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s2_r1
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s2_r2
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s2_r2
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s2_r3
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s2_r3
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s2_r4
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s2_r4


python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s3_r0
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s3_r0
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s3_r1
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s3_r1
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s3_r2
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s3_r2
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s3_r3
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s3_r3
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s3_r4
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s3_r4


python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s4_r0
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s4_r0
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s4_r1
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s4_r1
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s4_r2
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s4_r2
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s4_r3
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s4_r3
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s4_r4
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s4_r4


python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s5_r0
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s5_r0
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s5_r1
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s5_r1
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s5_r2
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s5_r2
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s5_r3
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s5_r3
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltpareto  --name s5_r4
python test/eval_for_paper.py --env-name ft7 --method crl-envelope --model  linear --gamma  0.99 --save crl/envelope/saved/ --pltcontrol --name s5_r4
