python run_a3c.py \
	--env-id SuperMarioBros-v2 \
	--use-gae \
	--life-done \
	--single-stage \
	--training \
	--standardization \
	--num-worker 2 \
