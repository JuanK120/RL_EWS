python run_n3c.py \
	--env-id SuperMarioBros-v2 \
	--use-gae \
	--life-done \
	--single-stage \
	--training \
	--standardization \
	--num-worker 2 \
	--sample-size 2 \
