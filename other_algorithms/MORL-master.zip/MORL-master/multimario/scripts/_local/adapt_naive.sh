python adapt_n.py \
	--env-id SuperMarioBros-v2 \
	--life-done \
	--single-stage \
	--load-model \
	--prev-model SuperMarioBros-v2_n3c_Dec15_03-40-48.model
