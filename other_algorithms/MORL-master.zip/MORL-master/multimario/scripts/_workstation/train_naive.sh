python run_n3c.py \
	--env-id SuperMarioBros-v2 \
	--use-cuda \
	--use-gae \
	--life-done \
	--single-stage \
	--training \
	--standardization \
	--num-worker 10 \
	--sample-size 8 \
