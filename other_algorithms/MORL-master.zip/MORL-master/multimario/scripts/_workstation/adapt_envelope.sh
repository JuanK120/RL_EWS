python adapt_e.py \
	--env-id SuperMarioBros-v2 \
	--use-cuda \
	--life-done \
	--single-stage \
	--load-model \
	--prev-model SuperMarioBros-v2_e3c_b95_Jan21_08-38-27.model
