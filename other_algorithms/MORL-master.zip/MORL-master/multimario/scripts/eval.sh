python eval_n3c.py \
	--env-id SuperMarioBros-v2 \
	--load-model \
	--prev-model SuperMarioBros-v2_n3c_Dec15_03-40-48.model \
	--use-gae \
	--life-done \
	--single-stage \
	--standardization \
	--num-worker 1 \
	--sample-size 1 \