Semantic Parsing
*********************

.. |.| raw:: html

   <br />
   
   
.. automodule:: semi.SemI
    :members:
    :private-members:
   
.. automodule:: semi.RuleSemIMethods
.. autoclass:: semi.RuleSemIMethods.PassthroughSemI
.. autoclass:: semi.RuleSemIMethods.RegexSemI

.. automodule:: semi.RegexSemI
.. autoclass:: semi.RegexSemI.RegexSemI
