Agent - the Complete Dialogue System
************************************


.. |.| raw:: html

   <br />


.. automodule:: Agent
   :members:
    

