****************
Acknowledgements
****************

The following current and former group members have contributed to PyDial (in alphabetical order):

- Paweł Budzianowski
- Iñigo Casanueva
- Milica Gašić
- Dongho Kim
- Nikola Mrkšić
- Lina Rojas-Barahona
- Stefan Ultes
- Pei-Hao Su
- David Vandyke
- Gellert Weisz
- Tsung-Hsien Wen
- Steve Young
