Simulation
***************

.. |.| raw:: html

   <br />
   
   
.. automodule:: usersimulator.SimulatedUsersManager
   :members:

.. automodule:: usersimulator.ConfidenceScorer
   :members:
  
.. automodule:: usersimulator.ConfusionModel
   :members:
      
.. automodule:: usersimulator.ErrorModel
   :members:
        
.. automodule:: usersimulator.ErrorSimulator
   :members:
   
.. automodule:: usersimulator.NBestGenerator
   :members:
  
.. automodule:: usersimulator.UserModel
   :members:
   
.. automodule:: usersimulator.UMHdcSim
   :members:
 
