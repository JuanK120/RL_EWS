Functional Tests
***************************

.. |.| raw:: html

   <br />
   
.. include:: ../tests/README.rst


List of Current Tests
======================
 

.. automodule:: tests.test_DialogueServer
   :members:

.. automodule:: tests.test_Simulate
   :members:

.. automodule:: tests.test_Tasks
   :members:
     