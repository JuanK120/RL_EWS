Evaluation
***************

.. |.| raw:: html

   <br />
   

.. automodule:: evaluation.EvaluationManager
   :members:
   :private-members:  

.. automodule:: evaluation.SuccessEvaluator
.. autoclass:: evaluation.SuccessEvaluator.ObjectiveSuccessEvaluator
.. autoclass:: evaluation.SuccessEvaluator.SubjectiveSuccessEvaluator
   


