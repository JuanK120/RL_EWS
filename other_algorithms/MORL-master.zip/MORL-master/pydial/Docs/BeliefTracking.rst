Belief Tracking
***********************

.. |.| raw:: html

   <br />

.. automodule:: belieftracking.BeliefTrackingManager
   :members:
   :private-members:
   
.. automodule:: belieftracking.BeliefTracker
   :members:
   :private-members:

.. automodule:: belieftracking.baseline
.. autoclass:: belieftracking.baseline.BaselineTracker
.. autoclass:: belieftracking.baseline.FocusTracker

.. automodule:: belieftracking.BeliefTrackingUtils
   :members:


